=== jqPlot for WordPress ===
Contributors: Ramoonus
Donate link: http://www.ramoonus.nl/donate/
Tags: javascript, jquery, excanvas, jqplot
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.0.0.1012

jqPlot is a pure JavaScript charting plugin for the jQuery javascript framework. 
== Description ==
jqPlot is a plotting and charting plugin for the jQuery Javascript framework. jqPlot produces beautiful line, bar and pie charts with many features.

== Installation ==
1. Upload `jqplot/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions == 
None at this moment.

== Upgrade Notice == 


== Screenshots ==
Not relevant.

== Changelog ==
= 1.0.0.1012 =
* Based on 1.0.0 beta 2 build 1012 (november 2011)
* Code optimalisation
* Readme update

= 0.8.2.792 = 
* Initial version
* Based on 1.0 beta 2 build 792